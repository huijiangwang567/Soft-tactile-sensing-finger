classdef soft_finger_PLANT_TYPE <  Simulink.IntEnumType
    enumeration
        DOF_Z (1)
        DOF_XZ (2)
    end
end

