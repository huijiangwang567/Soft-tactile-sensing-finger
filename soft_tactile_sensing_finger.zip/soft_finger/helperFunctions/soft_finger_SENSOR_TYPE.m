classdef soft_finger_SENSOR_TYPE <  Simulink.IntEnumType
    enumeration
        MLFUNC          (1)
        SSC             (2)
    end
end

