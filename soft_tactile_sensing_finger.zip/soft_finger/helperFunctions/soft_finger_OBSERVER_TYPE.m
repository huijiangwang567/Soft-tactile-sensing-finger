classdef soft_finger_OBSERVER_TYPE <  Simulink.IntEnumType
    enumeration
        BAGGED          (1)
        BAGGED2DOF      (2)
        LSTM            (3)
        SVM             (4)
        LINREG          (5)
        SS              (6)
        KF              (7)
        CUSTOM          (8)
        OFF             (9)
    end
end

