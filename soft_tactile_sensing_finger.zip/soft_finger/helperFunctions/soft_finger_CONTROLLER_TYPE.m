classdef soft_finger_CONTROLLER_TYPE <  Simulink.IntEnumType
    enumeration
        CONTACT_Z       (1)
        CONTACT_XZ      (2)
        RANDOMWALK_Z    (3)
        RANDOMWALK_XZ   (4)
        CUSTOM          (5)
    end
end

